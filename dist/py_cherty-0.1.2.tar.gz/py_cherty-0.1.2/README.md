# py_cherty
Python SDK for checkpointing data 

py_cherty is a Python package to send messages to an Electron app using socket communication.

## Installation

```bash
pip install py_cherty
